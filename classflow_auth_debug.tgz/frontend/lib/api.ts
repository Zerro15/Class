export const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
export const TOKEN_KEY = "classflow_token";
const PUBLIC = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const INTERNAL = process.env.API_INTERNAL_URL || "http://backend:8000";


export const tokenStorage = {
  
  get(): string | null {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(TOKEN_KEY);
  },
  set(token: string) {
    if (typeof window === "undefined") return;
    localStorage.setItem(TOKEN_KEY, token);
  },
  clear() {
    if (typeof window === "undefined") return;
    localStorage.removeItem(TOKEN_KEY);
  },
};

type RequestOptions = RequestInit & { json?: unknown };

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const headers = new Headers(opts.headers || {});
  headers.set("Accept", "application/json");

  const token = tokenStorage.get();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let body = opts.body;
  if (opts.json !== undefined) {
    headers.set("Content-Type", "application/json");
    body = JSON.stringify(opts.json);
  }

  const res = await fetch(`${API_URL}${path}`, { ...opts, headers, body });

  if (!res.ok) {
    const ct = res.headers.get("content-type") || "";
    const payload = ct.includes("application/json")
      ? JSON.stringify(await res.json())
      : await res.text();
    throw new Error(payload || `HTTP ${res.status}`);
  }

  // на случай 204/empty
  const text = await res.text();
  return (text ? (JSON.parse(text) as T) : ({} as T));
}

/** ===== Типы (под текущий фронт) ===== */
export interface Student {
  id: number;
  name: string;
  notes?: string | null;
}

export interface Lesson {
  id: number;
  student_id: number;
  start_at: string;
  duration_min: number;
  status: string;
  topic?: string | null;
  price: number;
}

export type LessonUpdate = {
  status?: string;
  topic?: string | null;
  start_at?: string;
  duration_min?: number;
  price?: number;
};

export type PaymentUpdate = {
  is_paid?: boolean;
  paid_amount?: number;
  paid_at?: string | null;
};

export type HomeworkUpdate = {
  text?: string | null;
  link?: string | null;
  is_sent?: boolean;
  sent_at?: string | null;
};

export type CreateStudentInput = {
  name: string;
  notes?: string | null;
};

export type CreateLessonInput = {
  student_id: number;
  start_at: string;
  duration_min: number;
  price: number;
  topic?: string | null;
};

export const api = {
  login(email: string, password: string) {
    return request<{ access_token: string; token_type: string }>("/api/v1/auth/login", {
      method: "POST",
      json: { email, password },
    });
  },

  register(email: string, password: string) {
    return request<{ access_token: string; token_type: string }>("/api/v1/auth/register", {
      method: "POST",
      json: { email, password },
    });
  },

  getUpcoming(days: number = 7) {
    return request<{ items: Lesson[] }>(`/api/v1/dashboard/upcoming?days=${encodeURIComponent(days)}`, {
      method: "GET",
    });
  },

  // ===== Students =====
  listStudents() {
    return request<{ items: Student[] }>("/api/v1/students", { method: "GET" });
  },

  createStudent(data: CreateStudentInput) {
    return request<Student>("/api/v1/students", { method: "POST", json: data });
  },

  getStudent(studentId: string | number) {
    return request<Student>(`/api/v1/students/${studentId}`, { method: "GET" });
  },

  // ===== Lessons =====
  createLesson(data: CreateLessonInput) {
    return request<Lesson>("/api/v1/lessons", { method: "POST", json: data });
  },

  requestLesson(lessonId: number) {
    return request<Lesson>(`/api/v1/lessons/${lessonId}`, { method: "GET" });
  },

  updateLesson(lessonId: number, data: LessonUpdate) {
    return request<Lesson>(`/api/v1/lessons/${lessonId}`, {
      method: "PUT",
      json: data,
    });
  },

  updatePayment(lessonId: number, data: PaymentUpdate) {
    return request(`/api/v1/lessons/${lessonId}/payment`, {
      method: "PUT",
      json: data,
    });
  },

  updateHomework(lessonId: number, data: HomeworkUpdate) {
    return request(`/api/v1/lessons/${lessonId}/homework`, {
      method: "PUT",
      json: data,
    });
  },
};
