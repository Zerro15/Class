"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import Link from "next/link";

import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";

interface Student {
  id: number;
  name: string;
  notes?: string | null;
}

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [name, setName] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.listStudents();
      setStudents(data.items as Student[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    try {
      await api.createStudent({ name, notes: notes || null });
      setName("");
      setNotes("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка");
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-white p-6 shadow-sm">
        <h1 className="text-xl font-semibold">Ученики</h1>
        <form className="mt-4 grid gap-3 md:grid-cols-3" onSubmit={handleCreate}>
          <input
            className="rounded border px-3 py-2"
            placeholder="Имя"
            value={name}
            onChange={(event) => setName(event.target.value)}
            required
          />
          <input
            className="rounded border px-3 py-2"
            placeholder="Заметки"
            value={notes}
            onChange={(event) => setNotes(event.target.value)}
          />
          <Button type="submit">Создать ученика</Button>
        </form>
        {error ? <p className="mt-3 text-sm text-red-600">{error}</p> : null}
      </div>

      <div className="rounded-lg border bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold">Список</h2>
        {loading ? <p className="mt-3 text-sm">Загрузка...</p> : null}
        {!loading && students.length === 0 ? (
          <p className="mt-3 text-sm text-slate-600">Пока нет учеников.</p>
        ) : null}
        <ul className="mt-4 space-y-3">
          {students.map((student) => (
            <li key={student.id} className="flex items-center justify-between">
              <div>
                <p className="font-medium">{student.name}</p>
                {student.notes ? <p className="text-xs text-slate-500">{student.notes}</p> : null}
              </div>
              <Link className="text-sm text-slate-600 hover:text-slate-900" href={`/students/${student.id}`}>
                Карточка
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
